## Deploy a Basic Node App using Now

This is a demo for an article.
Article URL will be updated once published.
